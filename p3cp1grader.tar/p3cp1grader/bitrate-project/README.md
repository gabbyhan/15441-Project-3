bitrate-project
===============

Project 3 for 15-441 CMU
