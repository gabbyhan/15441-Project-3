#include "pq.h"
#include <string.h>
#include <sys/stat.h>

int get_servers(char **servers, char *path);

void run_dijkstra(char *full_path, char *client_ip, char *server_ip);



