#include "customsocket.h"
#include "dns_msg.h"
#include "dijkstra.h"

int start_server(int argc, char* argv[]);
